#include <stdio.h>
#include <stdlib.h>
#define BUFF_SIZE 10000000

int main(void)
{
  FILE    *fp;
  char  *pout;

  int       i;
  int       c;
  int      sz;
  int    size;

  size = 0;
  sz  = sizeof(char);
  sz *= BUFF_SIZE;
  pout = (char*) malloc(sz);

  fp = fopen("global_config", "r");

  while((c = fgetc(fp)) != EOF)
  {
    if (c == '@')
    {
      pout[size] = '@';
      size++;
      while ( (c =fgetc(fp)) != '\n')
      {
        pout[size] = c; 
        size++;
      }
      pout[size] = c;//Copia retorno de carro 
      size++;
    }
    else if ( 
             (  ((c >='0') && (c <= '9')) || ((c >= 'a') && (c <= 'z')) )
          || (  ((c >='A') && (c <= 'Z')) || (c == '_'))
            )
    {
      pout[size] = c;
      size++; 
    }
    else if (c == '=')
    {
      pout[size] = c;
      size++;
      while ((c = fgetc(fp)) != '\n')
      {
        size++;
        size--; 
      }
      pout[size] = c;//Copia retorno de carro
      size++;
    }
  }

  fclose(fp);


  fp = fopen("config_script", "w+");

  for ( i = 0; i < size ; i++ )
  {
    fputc(pout[i],fp);
  }

  fclose(fp);

  return 0;
}
