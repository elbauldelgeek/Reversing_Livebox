#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define hashsize(n) ((unsigned int)1<<(n))
#define hashmask(n) (hashsize(n)-1)

#define BUFF_SIZE 10000000

#define BUFFER_MAX 3000
#define NUMBER_FLAG       0
#define RANGE_FLAG        1

#define MAX_STRING_BUCKETS   131072//2^17
#define MAX_STRING_BUCKETS_BITS  17//2^17
#define MAX_GROUP_ELEMENTS      500
#define MAX_TOKENS            10000

#define MAX_COLLITIONS          100

typedef int strings_id;

//Parsing info
//Tokens identities
typedef enum
{
TOKEN_GROUP_RANGE,
TOKEN_GROUP_ID,        
TOKEN_VAR,             //VARiable token
TOKEN_NONE_LIMIT
}tokens;

typedef struct
{
int                      tokens_num;
int              tokens[MAX_TOKENS];//mark for elements in bucket
}tokens_string;
//

typedef struct
{
int                 colli_values;
char*     string[MAX_COLLITIONS];
}collisions_values;

typedef struct
{
int                    max_pointers;
char*    string[MAX_STRING_BUCKETS];
int        hash[MAX_STRING_BUCKETS];
int  collisions[MAX_STRING_BUCKETS];//mark for elements in bucket
}string_pointers;

typedef struct
{
int                       instance_id;
int                    number_of_keys;
strings_id   keys[MAX_GROUP_ELEMENTS];
strings_id values[MAX_GROUP_ELEMENTS];
}group_keys;

typedef struct
{
int                            range_or_id;//range = 1, id = 0 
int                          group_name_id;
int                    number_of_instances;
int                         first_instance;//range1
group_keys  *instances[MAX_GROUP_ELEMENTS];
}group;

typedef struct
{
int number_of_groups;
group groups[MAX_GROUP_ELEMENTS];
}groups_mem;

