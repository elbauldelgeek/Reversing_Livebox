#include "config_structs.h"

//GLOBALS
char  global_char_big_buffer[BUFFER_MAX];
int               global_big_buffer_size;

string_pointers          global_hash_mem;
groups_mem             global_groups_mem;
tokens_string          global_tokens_mem;
collisions_values  global_collisions_mem;

//Start of hash code
unsigned int get_hash(unsigned char* str)
{
  unsigned int     hash;
  unsigned int     buff;
  unsigned int    buff2;
  unsigned int    buff3;
  unsigned int hash_val;
  int               c;
  hash = 0;
  char        *str2;

  str2 = str;
  while( c = *str2++)
  {
    buff  = hash;
    buff2 = hash <<  6;
    buff3 = hash << 16;
    hash  = c;
    hash += buff2;
    hash += buff3;
    hash -= buff;
  }

/*
  uint32_t hash_val;
  int        length;

  //  length in bytes of string

  length = 0;
  str2 = str;
  while( c = *str2++)
  {
    length++;
  } 
  //Hashlittle reads chunks of 32 bit data so assert next bytes are clear from old strings
  str[length]   = '\0';
  str[length+1] = '\0';
  str[length+2] = '\0';
  str[length+3] = '\0';


  hash_val = hashlittle( str, length, 0);
  */
  hash_val = hash;
  hash_val = (hash_val & hashmask(MAX_STRING_BUCKETS_BITS));

  hash = (unsigned int)hash_val;
 
  return (hash); 
}

int get_index(char *str,int num_buckets)
{
  int                index;
  unsigned  int       hash;

  hash = get_hash((unsigned char*)str);

  index = (int)hash;
  return(index);
}

//End of hash code

//Init code start
int program_init(string_pointers *hash_mem)
{
  int i;

  for (i = 0; i < MAX_STRING_BUCKETS; i++)
  {
  hash_mem->collisions[i] = -1;
  }

  global_groups_mem.number_of_groups = 0;

  global_collisions_mem.colli_values = 0;

  return(0);
}

//End init code

int get_next_string(int i,FILE* fp)
{
  char c;

  while ( (c =fgetc(fp)) != '\n')
  {
  if (c == '\0'){break;}
  if (c == ' '){continue;}
  if (c == '='){continue;}
  global_char_big_buffer[i] = c; 
  i++;
  }

  global_char_big_buffer[i] = '\0';//Store end end of string
  global_big_buffer_size = i;

  return(0);
}

int get_num(char *num_in_chars)
{
  int  num;
  int  val;

  num = 0;
  val = num_in_chars[0] - '0';
  num += val * 100;
  val = num_in_chars[1] - '0';
  num += val * 10;
  val = num_in_chars[2] - '0';
  num += val;

  return(num);
}

int get_number(int index,int chars_num,char *char_big_buffer)
{
  int                i;
  int              num;
  int          t_index;
  int         t_index2;
  char num_in_chars[]={'0','0','0'};

  if ((chars_num == 0) || (chars_num > 3))
  {exit(-1);}

  for (i = 0; i < chars_num ; i++)
  {
    t_index   = 2 - i;
    t_index2  = index;
    t_index2 += chars_num -1;
    t_index2 -= i;
    num_in_chars[t_index] = char_big_buffer[t_index2]; 
  }
  num = get_num(num_in_chars);

  return(num);
}

int get_range(int index,char *char_big_buffer,int big_buffer_size, int *range1, int *range2)
{
  int                i;
  int                j;
  int                k;
  int              num;
  int             num1;
  int             num2;
  int          t_index;
  int         t_index2;
  char               c;
  char num_in_chars[]={'0','0','0'};

  for (i = index; i < big_buffer_size; i++)
  {
  c = char_big_buffer[i];
  if (c == ':')
  break;
  }

  k = i;
  j = i - index;
  if ((j == 0) || (j > 3))
  {exit(-1);}

  for (i = 0; i < j ; i++)
  {
    t_index   = 2 - i;
    t_index2  = index;
    t_index2 += j - 1;
    t_index2 -= i;
    num_in_chars[t_index] = char_big_buffer[t_index2]; 
  }
  *range1 = get_num(num_in_chars);

  j = big_buffer_size - k;
  j -= 2;//'\n' and ]
  if ((j == 0) || (j > 3))
  {exit(-1);}
 
  for (i = 0; i < j ; i++)
  {
    t_index   = 2 - i;
    t_index2  = k;
    t_index2 += j;
    t_index2 -= i;
    num_in_chars[t_index] = char_big_buffer[t_index2];
  }
  *range2 = get_num(num_in_chars);

  return (0);
}

//return negative index values for collided values
int get_collision_string_index(char *str, string_pointers *hash_mem)
{
  int                         i;
  int                        eq;
  collisions_values *collisions;
  collisions = &global_collisions_mem;
  
  for ( i = 0; i < collisions->colli_values ; i++ )
  {
    eq = strcmp(collisions->string[i], str);
    if (eq == 0)
    {
      return(-i-1);//index found, 0 is used for positive hash values 
    }
  }

  if ((i+1) > MAX_COLLITIONS)
  {
    printf("Too much collisions\n");
    fflush(stdout);
    exit(-2);
  }
 
  collisions->string[i] = strdup(str);  
  (collisions->colli_values)++;

  return (-i-1);
}

int get_string_index(char *str, string_pointers *hash_mem)
{
  int num_buckets;
  int       index;
  int       colli;
  int          eq;
  num_buckets = MAX_STRING_BUCKETS;

  index = get_index(str,num_buckets);

  colli = (hash_mem->collisions[index]);

  if (colli >= 0)
  { 
    eq = strcmp(hash_mem->string[index], str);
    if (eq != 0)
    {
      printf("Collision Value\n");
      fflush(stdout);
      
      index = get_collision_string_index(str, hash_mem);
      return(index);
    }
    else
    {return(index);}
  }
  else
  {
    hash_mem->string[index] = strdup(str);
    colli++;
  }
  (hash_mem->collisions[index]) = colli;

  return(index);
}

char*
get_string_from_index(int str_index, string_pointers *hash_mem)
{
  char                           *str;
  collisions_values       *collisions;
  collisions = &global_collisions_mem;

  if (str_index >= 0)
  {
    str = hash_mem->string[str_index];
  }
  else//Collided vals
  {
    int index;
    index = str_index;
    index++;//0 index is used by hash table
    index = -index;
    if (index > (collisions->colli_values))
    {exit(-3);}
    str = collisions->string[index]; 
  }

  return(str);
}

int write_group_id(FILE *fp)
{
  int                         i;
  int                   group_c;
  int                 string_id;
  int                    number;
  int                    range1;
  int                    range2;
  int           number_or_range;//flag
  
  char                        c;
  char group_string[BUFFER_MAX];  

  get_next_string(0,fp);

  group_c = 0;
  number  = 0;//Default number 0 id
  number_or_range = NUMBER_FLAG;
  for (i = 0; i < global_big_buffer_size; i++)
  {
  c = global_char_big_buffer[i];
  group_string[i] = c;
  group_c++; 
  if (c == '#')
  {
    if ((global_char_big_buffer[i+1]) == '0')
    {
    number = get_number(i+2,2,global_char_big_buffer);//read two chars
    number_or_range = NUMBER_FLAG;
    }
    else if ((global_char_big_buffer[i+1]) == '[')
    {
    get_range(i+2,global_char_big_buffer,global_big_buffer_size, &range1, &range2);
    number_or_range = RANGE_FLAG;
    }

    group_string[group_c-1] = '\0';//end string here
    break;//From for loop
  }
  else if((i+1) == global_big_buffer_size)
  {
    group_string[group_c] = '\0';//end string here
  } 
  }

  int          tokens_num;
  tokens_string   *tokmem;

  string_id =  get_string_index(group_string, &global_hash_mem);

  tokmem = &global_tokens_mem;
  tokens_num = tokmem->tokens_num;
  if (number_or_range == RANGE_FLAG)
  {
    tokmem->tokens[tokens_num] = TOKEN_GROUP_RANGE;
    (tokens_num)++;
    tokmem->tokens[tokens_num] = string_id;
    (tokens_num)++;
    tokmem->tokens[tokens_num] = range1;
    (tokens_num)++;
    tokmem->tokens[tokens_num] = range2;
    (tokens_num)++;
    (tokmem->tokens_num) = tokens_num;
  }
  else
  {
    tokmem->tokens[tokens_num] = TOKEN_GROUP_ID;
    (tokens_num)++;
    tokmem->tokens[tokens_num] = string_id;
    (tokens_num)++;
    tokmem->tokens[tokens_num] = number;
    (tokens_num)++;
    (tokmem->tokens_num) = tokens_num;
  }

  return(0);
}

int write_var_id(char c, FILE *fp)
{
  int                 string_id;

  if (c == '\n'){return(0);}
  else
  {
    global_char_big_buffer[0] = c; 
    get_next_string(1,fp);
  }

  int      tokens_num;
  string_id =  get_string_index(global_char_big_buffer,&global_hash_mem);

  tokens_num = global_tokens_mem.tokens_num;

  global_tokens_mem.tokens[tokens_num] = TOKEN_VAR;
  (tokens_num)++;
  global_tokens_mem.tokens[tokens_num] = string_id;
  (tokens_num)++;
  (global_tokens_mem.tokens_num) = tokens_num;

  return(0);
}

int save_token(int *index,FILE *fp)
{
  int                   i;
  int               token;  
  int           str_index;
  char               *str;
  tokens_string   *tokmem;

  i = *index;
  tokmem = &global_tokens_mem;
  token = tokmem->tokens[i];

  if (token == TOKEN_GROUP_RANGE)
  {
    int        num1;
    int        num2;
    int   str_index;
    i++;
    str_index = tokmem->tokens[i];
    str = get_string_from_index(str_index, &global_hash_mem);
    i++;
    num1 = global_tokens_mem.tokens[i];
    i++;
    num2 = global_tokens_mem.tokens[i];
    i++;
 
    fprintf(fp, "+++ Token GROUP Range,name:%s,%d-%d\n",str , num1, num2);
  }  
  else if (token == TOKEN_GROUP_ID)
  {
    int         num;
    i++;
    str_index = tokmem->tokens[i];
    i++;
    num = tokmem->tokens[i];
    i++;
    str = get_string_from_index(str_index, &global_hash_mem);
    if (num != 0)
    {fprintf(fp, "+++ Token GROUP id,name:%s,%d\n",str,num);}
    else
    {fprintf(fp, "+++ Token GROUP id,name:%s\n", str);}
  }
  else if (token == TOKEN_VAR) 
  {
    i++;
    str_index = tokmem->tokens[i];
    i++;
    str = get_string_from_index(str_index, &global_hash_mem);
    fprintf(fp, "Token Variable,name:%s\n", str);
  }

  *index = i;

  return(0);
}


int create_new_group(int range_or_id, int str_id ,int range1_or_id, int range2)
{
  int            i;
  int       grp_id;
  group       *grp;
  groups_mem *gmem;
  group_keys   *gk;

  gmem = &global_groups_mem;

  grp_id = gmem->number_of_groups;
  grp = &(gmem->groups[grp_id]);

  grp->group_name_id = str_id;
  if (range_or_id > 0)//Create group range
  {
    int     ins_num;
    grp->range_or_id = 1;
    ins_num = range2 - range1_or_id;
    grp->number_of_instances = ins_num;
    grp->first_instance      = range1_or_id;
    for ( i = 0; i < ins_num; i++)
    {
      gk = (group_keys*)malloc(sizeof(group_keys));
      gk->instance_id = i + range1_or_id;
      gk->number_of_keys = 0;
      grp->instances[i] = gk;
    }
  }
  else
  {
    grp->range_or_id = 0;
    grp->number_of_instances = 1;
    grp->first_instance      = range1_or_id;
    gk = (group_keys*)malloc(sizeof(group_keys));
    gk->instance_id = 0;
    gk->number_of_keys = 0;
    grp->instances[0] = gk;
  }  
 
  (gmem->number_of_groups)++; 

  return(0);
}

int add_var_to_group(int str_index)
{
  int            i;
  int          num;
  int         keys;
  int       grp_id;
  int  range_or_id;
  group       *grp;
  groups_mem *gmem;
  group_keys   *gk;

  gmem = &global_groups_mem;

  grp_id = gmem->number_of_groups - 1;//Last group
  grp = &(gmem->groups[grp_id]);

  range_or_id = grp->range_or_id;
  if (range_or_id > 0)//Group range
  {
    num = grp->number_of_instances;
    for ( i = 0; i < num; i++)
    {
      gk   = grp->instances[i];
      keys = gk->number_of_keys;
      gk->keys[keys] = str_index;
      gk->values[keys] = -1; 
      (gk->number_of_keys)++;
    }
  }
  else
  {
    gk   = grp->instances[0];
    keys = gk->number_of_keys;

    gk->keys[keys] = str_index;
    gk->values[keys] = -1; 
    (gk->number_of_keys)++;
  }  
 
  return(0);
}

int save_token_in_struct(int *index)
{
  int                   i;
  int               token;  
  int           str_index;
  char               *str;
  tokens_string   *tokmem;

  i = *index;
  tokmem = &global_tokens_mem;
  token = tokmem->tokens[i];

  if (token == TOKEN_GROUP_RANGE)
  {
    int        num1;
    int        num2;
    int   str_index;
    i++;
    str_index = tokmem->tokens[i];
    str = get_string_from_index(str_index, &global_hash_mem);
    i++;
    num1 = global_tokens_mem.tokens[i];
    i++;
    num2 = global_tokens_mem.tokens[i];
    i++;

    create_new_group(1, str_index, num1, num2);
  }  
  else if (token == TOKEN_GROUP_ID)
  {
    int         num;
    i++;
    str_index = tokmem->tokens[i];
    i++;
    num = tokmem->tokens[i];
    i++;
    str = get_string_from_index(str_index, &global_hash_mem);
    create_new_group(0, str_index, num, 0);
  }
  else if (token == TOKEN_VAR) 
  {
    i++;
    str_index = tokmem->tokens[i];
    i++;
    str = get_string_from_index(str_index, &global_hash_mem);

    add_var_to_group(str_index);
  }

  *index = i;

  return(0);
}

int read_tokens()
{
  int            i;
  int tokens_limit;  

  tokens_limit = global_tokens_mem.tokens_num;

  i = 0;
  while (i < tokens_limit)
  {save_token_in_struct(&i);}

  return(0);
}

int save_request(group_keys *gk, int group_name_id,int group_instance, FILE *fp)
{
  int              i;
  int       keys_num;
  int      str_index;
  int   gp_str_index;
  char *group_string;
  char   *key_string;

  keys_num = gk->number_of_keys;
  group_string = get_string_from_index(group_name_id, &global_hash_mem);

  for (i = 0; i < keys_num; i++)
  {
    str_index = gk->keys[i];
    key_string   = get_string_from_index(str_index, &global_hash_mem);
    fprintf(fp, "%s@%s", key_string,group_string);
    if (group_instance != 0)
    {
      fprintf(fp, "#%03d", group_instance);
    }
    fprintf(fp, "\n");
  }

  return(0);
} 

int save_requests(FILE *fp)
{
  int            i;
  int            j;
  int tokens_limit;  

  int          num;
  int         keys;
  int    grp_limit;
  int  range_or_id;
  group       *grp;
  groups_mem *gmem;
  group_keys   *gk;

  gmem = &global_groups_mem;

  grp_limit = gmem->number_of_groups;//Last group
  for (i = 0; i < grp_limit; i++)
  {
    grp = &(gmem->groups[i]);

    range_or_id = grp->range_or_id;
    if (range_or_id > 0)//Group range
    {
      int first_instance;
      num = grp->number_of_instances;
      for ( j = 0; j < num; j++)
      {
        gk   = grp->instances[j];
        save_request (gk,grp->group_name_id,first_instance + j, fp);
      }
    }
    else
    {
      gk   = grp->instances[0];
      save_request (gk,grp->group_name_id,0, fp);
    }  
  }

  return(0);
}

int main(void)
{
  FILE    *fp;
  char  *pout;

  int       i;
  int       c;
  int      sz;
  int    size;

  size = 0;
  sz  = sizeof(char);
  sz *= BUFF_SIZE;
  pout = (char*) malloc(sz);

  program_init(&global_hash_mem);

  fp = fopen("config_script", "r");

  while((c = fgetc(fp)) != EOF)
  {
    if (c == '@')
    {
      write_group_id(fp);//Write tokens
    }
    else
    {
      write_var_id(c,fp);
    }
  }
  fclose(fp);


  read_tokens();

  fp = fopen("config_request", "w+");
  save_requests(fp);
  fclose(fp);

  return 0;
}
